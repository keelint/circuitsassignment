﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Circuits
{
    public class Compound : Gate
    {

        /// <summary>
        /// list of gates
        /// </summary>
        public List<Gate> Gates 
            { get; set; }

        /// <summary>
        /// initialises a compound gate
        /// </summary>
        public Compound()
        {
            Gates = new List<Gate>();
            selected = false;

        }

        /// <summary>
        /// selected property so that all gates are selected or none
        /// </summary>
        public new bool Selected
        {
            get { return selected; }
            set
            {
                foreach(Gate gate in Gates)
                {
                    gate.Selected = value;
                }
            }
        }

        public override void Draw(Graphics paper)
        {
            Gates.ForEach(gate => gate.Draw(paper));

            //if (Selected)
            //{
            //    Gates.ForEach(gate => gate.Draw(paper));
            //}
        }

        /// <summary>
        /// method that adds a gate to the gates list
        /// </summary>
        public void AddGate(Gate g)
        {
            Gates.Add(g);
        }

        public override void MoveTo(int x, int y)
        {
            foreach (Gate g in Gates)
            {
                Point mouse = new Point(x, y);
                Point compoundOffset = pos - (Size)g.Position();
                g.MoveTo((mouse - (Size)compoundOffset).X, (mouse - (Size)compoundOffset).Y);
            }

        }

        public override Gate Clone()
        {
            Compound clone = new Compound();
            //clone.AddGate(Gates);
            return clone;
        }

        public override bool Evaluate()
        {
            foreach (Gate g in Gates)
            {
                if (g is OutputLamp)
                {
                    g.Evaluate();
                }
            }

            return false;
        }

    }
}
